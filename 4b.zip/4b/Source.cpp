#include <iostream>
#include<cstdlib>
using namespace std;

class HotDogStand
{
private:
	int IDnumber;
	int HotDogsSold;
	static int totalSold;

public:
	HotDogStand();
	HotDogStand(int IDnumber, int hotDogsSold);
	int getID();
	void setID(int ID);
	void JustSold();
	int getNumSold();
	static int getTotalSold();
};
int HotDogStand::totalSold = 0;

int main()
{
	HotDogStand a(1, 0);
	HotDogStand b(2, 0);
	HotDogStand c(3, 0);
	HotDogStand d;
	a.setID(1);
	b.setID(2);
	c.setID(3);
	a.JustSold();
	b.JustSold();
	a.JustSold();
	cout << "Id " << a.getID() << " sold " << a.getNumSold() << endl;
	cout << "Id " << b.getID() << " sold " << b.getNumSold() << endl;
	cout << "Id " << c.getID() << " sold " << c.getNumSold() << endl;
	cout << "Total sold=" << a.getTotalSold() << endl;
	system("PAUSE");
	return 0;
}
HotDogStand::HotDogStand()
{
	IDnumber = 0;
	HotDogsSold = 0;

}
HotDogStand::HotDogStand(int IDnumber, int hotDogsSold)
{
	IDnumber = IDnumber;
	HotDogsSold = hotDogsSold;
}
int HotDogStand::getID()
{
	return IDnumber;
}
void HotDogStand::setID(int newID)
{
	IDnumber = newID;
}
void HotDogStand::JustSold()
{
	HotDogsSold++;
	totalSold++;

}
int HotDogStand::getNumSold()
{
	return HotDogsSold;
}
int HotDogStand::getTotalSold()
{
	return totalSold;
}
