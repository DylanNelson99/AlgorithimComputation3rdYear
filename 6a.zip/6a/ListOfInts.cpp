//X00144862 Dylan Nelson

#include <iostream>
#include "ListOfInts.h"
using namespace std;
ListOfInts::ListOfInts()
    :head(NULL)
{}

ListOfInts::~ListOfInts(){};

void ListOfInts::insert(int data){
    // Creating a new node "newNode" and store the "data" in it
    NodeOfInt *newNode = new NodeOfInt(data);
    
    // Setting the pointer to the present first node on the list
    newNode->next = head;
    
    // Setting this node to be the head of the list
    head = newNode;
}

void ListOfInts::displayList(){
    ListNodePtr tempPointer = head;
    
    while (tempPointer != NULL){
        cout << tempPointer->data << endl;;
        tempPointer = tempPointer->next;
    }
}

void ListOfInts::deleteMostRecent(){
    ListNodePtr temp = head;
    if(head != NULL){
           head = head->next;
        delete temp;
       }
}

void ListOfInts::deleteInt(int pos){
    ListNodePtr leadPtr = head;
    ListNodePtr trailPtr = head;
    int indexCounter = 0;
    if(pos == 0){
        head = head->next;
        delete leadPtr;
    }
    
    else{
        while(leadPtr){
            if(pos == indexCounter){
                ListNodePtr trailPtr2;
        
                trailPtr2 = leadPtr;
            
                leadPtr = leadPtr->next;
                delete trailPtr2;
               
                trailPtr->next = leadPtr;
          
            }
            indexCounter++;
            trailPtr = leadPtr;
            leadPtr = leadPtr->next;
            
        }
    }
}
