//X00144862 Dylan Nelson

#ifndef ListOfInts_h
#define ListOfInts_h
#include "NodeOfInts.h"
class ListOfInts{
public:
    ListOfInts();
    ~ListOfInts();
    void insert(int);
    void displayList();
    void deleteMostRecent();
    void deleteInt(int pos);
    
private:
    ListNodePtr head;
};

#endif /* ListOfInts_h */
