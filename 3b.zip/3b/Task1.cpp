
//  LabSheet3_PartB
// Dylan Nelson


#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;
bool fillArray(char array[], int size);
int countMethod(int count);
void outputInReverse(char array[], int size);

                                 

int main(){
     int size = 0;
    cout<< "Enter a size for your list of characters"<< endl;
    
    cin >>size;
    char array[size];
    
    fillArray(array, size);
    outputInReverse(array, size);
    
}
// Task A
bool fillArray(char array[], int size){
    char input = ' ';
    int entryCount = 0;
    
        cout << "Enter a character e.g. (A / B) or '.' to terminate" << endl;
        cin >> input;
        while(input != '.')
        {
            array[entryCount] = input;
            entryCount++;
            cout << "Enter a character e.g. (A / B) or '.' to terminate" << endl;
            cin >> input;
            
        }
    cout << "Entry count: " << entryCount << endl;
    
    return true;
   
}

// Task B
//for(int i = 0,j = letters.size()-1; i<j ;i++ ,j--){
//       swap(letters[i],letters[j]);
//      }
//   cout<<letters<<'\n';
void outputInReverse(char array[], int size){
    for (int i = 0; i < size / 2; i++) {
        swap(array[i], array[size-1-i]);
    }
    
    cout << "Reverse order: " << endl;
    
    for(int i=0; i < size ; i++){
        cout << array[i];
    }
    cout << endl;
}
