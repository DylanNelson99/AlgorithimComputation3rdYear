//  LabSheet3_PartB
// Dylan Nelson

#include <iostream>
using namespace std;

void userInput(double array[], int size);
void Average(double array[], int size);
bool isNumber(double array[], int size);
int main(){
    
    int size = 0;
    cout << "Please enter array size: " << endl;
    cin >> size;
    double array[size];
    
    userInput(array, size);

    Average(array, size);
    
}

void userInput(double array[], int size){
    int value = 0;
    double input;
    
    while(value < size){
        value++;
        cout << "Please enter in nurmeric values: " << endl;
        cin >> input;
        if(cin >> input){
            
        }
        array[value] = input;
        
    
    }
}

void Average(double array[], int size){
    double total = 0.0;
    double average;
    int numsOverAvg = 0;
    
    for (int i = 0; i < size; i++) {
        total += array[i];
    }
    average = total / size;
    
    for (int i = 0; i < size; i++) {
           if(array[i] > average){
               numsOverAvg++;
           }
       }

    cout << "Count of numbers > average: " << numsOverAvg << endl;
    
    cout << "The average is: " << average << endl;
    
};
