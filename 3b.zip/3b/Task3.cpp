//  LabSheet3_PartB
// Dylan Nelson

#include <iostream>
using namespace std;
void userInput(int array[], int size, int& count);
void display(int array[], int size);
void average(int array[], int size);
void reverseOrder(int arraay[], int size);
void cutIndex(int array[], int size);

int main(){
    const int size = 12;
    int array[size];
    int count = 0;
    
    userInput(array, size, count);
    display(array, count);
    average(array, count);
    reverseOrder(array, count);
    cutIndex(array, count);
}

void userInput(int array[], int size, int& count){
    int value = 0;
    int input;
    
    while(value < size){
        
        cout << "Enter a number or 0 to stop: " << endl;
        cin >> input;
        array[value] = input;
        value++;
       if(input == 0){
            break;
        }
        count++;
    }
}

void display(int array[], int size){
    for (int i = 0; i < size; i++) {
        cout << array[i] << ", ";
    }
    cout << endl;
}

void average(int array[], int size){
    int total = 0;
    int average;
    
    for (int i = 0; i < size; i++) {
        total += array[i];
    }
    average = total / size;
    
    cout << "The average is: " << average << endl;
    
}

void reverseOrder(int array[], int size){
//   for (int i = 0; i < size / 2; i++) {
//        swap(array[i], array[size-1-i]);
//    }
//
    cout << "Reverse order: " << endl;
    for (int i = size - 1; i >= 0; i--) {
         cout << array[i] << ", ";
    }
    
//
//    for (int i = 0; i < size; i++) {
//
//    }
    cout << endl;
}

void cutIndex(int array[], int size){
    
    cout << "Array cut: " << endl;
    for (int i = 1; i < size-2; i++ ) {
        cout << array[i] << ", ";
    }
    cout << endl;
}

