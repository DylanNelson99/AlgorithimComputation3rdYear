#include <iostream>
using namespace std;

//making the functions
void userInput(); 
void output (int hours, int minutes, int seconds, char morningNight);
void conversion(int hours, int minutes, int seconds);

// initializng the function
void userInput() {

	int hours, minutes, seconds; 
	cout << "Enter hours (24 hour format): " << endl; // printing out a message
	cin >> hours; // assigning the answer to hours variable 

	cout << "Enter minutes: " << endl; 
	cin >> minutes;

	cout << "Enter seconds: " << endl;
	cin >> seconds;

	conversion(hours, minutes, seconds); //assigning the answers to the conversion function
};

// making the output function and outputting the hours minutes seconds and the morning night 
void output(int hours, int minutes, int seconds, char morningNight) {
	cout << hours << ":" << minutes << ":" << seconds << ".m." << morningNight << endl;
}

// conversion function
void conversion(int hours, int minutes, int seconds) {
	char morningNight = ' ';

	//if hours are greater then 12
	if (hours > 12)
	{
		hours = hours - 12;
		morningNight = 'p';
	}
	else if (hours == 12) morningNight = 'p';
	else morningNight = 'a';

	output(hours, minutes, seconds, morningNight);

};

int main() {
	userInput();
	
	return 0;
}