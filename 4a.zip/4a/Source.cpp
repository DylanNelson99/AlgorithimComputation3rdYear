//http://www.sr2jr.com/textbook-solutions/computer-science/40501002/absolute-cpp-arrays (Used small bits to help)
//Dylan Nelson

#include <iostream> 
using namespace std;

void deleteRepeated(char a[], int size, int& numbers_used);
void output(char a[], int& numbers_used);

int main()
{
	char array[10];// setting length of array
	int numbers_used;
	deleteRepeated(array, 10, numbers_used);
	output(array, numbers_used);
}

void deleteRepeated(char a[], int size, int& numbers_used)
{
	char c;
	int index = 0;
	cout << "Please type in your sentence and then press enter:\n";  // asking for the sentence to be entered
	cin.get(c);

	while (c != '\n' && index < size) {  // count each character entered adds them up into index then out puts below
		a[index] = c;
		cin.get(c);
		index++;
	}
	numbers_used = index;
	cout << "\nThe size of the array you entered is: " << endl << numbers_used; // outpuuting array size before repeats are taken out


	for (int i = 0; i < numbers_used; i++) {         //when array is populate from the sentence it checks for the repeating letters
		for (int j = i + 1; j < numbers_used; j++) {
			if (a[i] == a[j]) {                     
				numbers_used = numbers_used - 1;
				for (int k = j; k < numbers_used; k++)
					a[k] = a[k + 1];
				a[numbers_used] = '\0';
				--j;
			}
		}
	}
}

void output(char a[], int& numbers_used)
{
	cout << endl;
	cout << "The new sentence without the repeated letters is:\n"; // outputs array minus the repeating letters
	for (int i = 0; i < numbers_used; i++) {
		cout << a[i];
	}
	
	cout << "\nThe new size of the array you entered is: " << endl << numbers_used; // out puts new size of array(since repeating letter were taken out)

	cin.ignore();
	cin.get();
}