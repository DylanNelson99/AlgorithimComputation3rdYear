//Dylan Nelson

#ifndef ListOfDoubles_h
#define ListOfDoubles_h
#include "DoubleListNode.h"
class ListOfDoubles
{
    friend class StackOfDoubles;
public:
    ListOfDoubles();
    ~ListOfDoubles();
    void insert(double);
    void displayList(ostream &str) const;
    double deleteMostRecent();
    double deleteDouble(int pos);
private:
    DoubleListNode *head;
};

#endif /* ListOfDoubles_h */
