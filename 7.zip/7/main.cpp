//Dylan Nelson

#include "DoubleListNode.h"
#include "ListOfDoubles.h"
#include "StackOfDoubles.h"
#include <list>
#include <vector>
#include <iostream>
using namespace std;
int main() {
    StackOfDoubles object;
    object.push(5.0);
    object.push(6.0);
    object.push(3.0);
    
    cout << object;
    
    object.pop();
    cout << "-------" << endl;
    cout << object;
    cout << "-------" << endl;
    cout << object.top() << endl;
    cout << "-------" << endl;
    cout << "Part 2 Using Lists" << endl;
    
    list<double> myList;
    myList.push_back(7.6);
    myList.push_back(8.5);
    
    list<double> myListTemp(myList);
    
    while(myListTemp.empty() != true){ // while the list still has elements, loop through the list
        cout << myListTemp.front() << endl;
        myListTemp.pop_front();
    }
    
    cout << "Part 3 Using Vectors" << endl;
    vector<double> myVec;
    
    myVec.push_back(5.5); // [0]
    myVec.push_back(6.5); // [1]
    myVec.push_back(7.5); // [2]
    myVec.push_back(8.5); // [3]
    
    for(int i = 0; i < myVec.size(); i++){
        cout << myVec.at(i) << endl;
    }
    
    cout << "First value at front: " << myVec.front() << endl;
    
    myVec.pop_back(); // Lat element was popped out of the array    
    for(int i = 0; i < myVec.size(); i++){
        cout << myVec.at(i) << endl;
    }
}

