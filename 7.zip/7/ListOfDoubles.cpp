//Dylan Nelson

#include "ListOfDoubles.h"
#include "DoubleListNode.h"
#include <iostream>
using namespace std;

ListOfDoubles::ListOfDoubles()
    :head(NULL)
{}

ListOfDoubles::~ListOfDoubles()
{
    DoubleListNode *temp;
    while (head)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
}

void ListOfDoubles::insert(double val)
{
    DoubleListNode *newNode = new DoubleListNode(val);
    newNode->next = head;
    head = newNode;
}

void ListOfDoubles::displayList(ostream & str) const
{
    DoubleListNode *temp = head;
    while (temp)
    {
        str << temp->theValue << endl;
        temp = temp->next;
    }
}

double ListOfDoubles::deleteMostRecent()
{

    DoubleListNode *temp = head;

    double retval = 0;

    if (head)
    {
        retval = head->theValue;
        head = head->next;
    }


    delete temp;

    return retval;

}

double ListOfDoubles::deleteDouble(int pos)
{
    DoubleListNode *leader = head, *trailer = NULL;
    double retval = 0;
    
    if (pos < 1)
        return 0; //position not valid
    if (head == NULL)
        return 0;  // list has no postions 

     if (pos == 1) // deleting the head node
        //we want to bypass the head node
        head = head->next;  //but leader is still pointing to the old head
    else // else count through the list
    {
        for (int i = 1; leader != NULL && i < pos; i++)
        {
			// already executed the first node, now we need to itierate through the postion to get leader pointing to the -th node
            trailer = leader;
            leader = leader->next;
        }
        // if leader is returning null, we can end the postion
        // if not, we can now by pass leader with ->next
        if (leader)
            trailer->next = leader->next;
    }
    
    if (leader)
    {
        retval = leader->theValue;
        delete leader;
    }
    
    return retval;  
