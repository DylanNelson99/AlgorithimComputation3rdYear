//Dylan Nelson

#ifndef StackOfDoubles_h
#define StackOfDoubles_h
#include "ListOfDoubles.h"

class StackOfDoubles{
    friend ostream & operator<<(ostream& str, const StackOfDoubles &stackobj);
public:
    StackOfDoubles();
    ~StackOfDoubles();
    void push (const double number);
    void pop();
    double top();
    
private:
    ListOfDoubles stack;
};

#endif /* StackOfDoubles_h */
