//Dylan Nelson

#include "DoubleListNode.h"

DoubleListNode::DoubleListNode(double val)
    :next(NULL), theValue(val)
{}

