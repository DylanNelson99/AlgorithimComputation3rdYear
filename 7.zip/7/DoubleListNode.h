//Dylan Nelson

#ifndef DoubleListNode_h
#define DoubleListNode_h

#include <iostream>
using namespace std;

class DoubleListNode
{
    friend class StackOfDoubles;
    friend class ListOfDoubles;
public:
    DoubleListNode(double = 0);
private:
    double theValue;
    DoubleListNode *next;
};

#endif /* DoubleListNode_h */
