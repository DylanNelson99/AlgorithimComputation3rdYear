//Dylan Nelson

#include "StackOfDoubles.h"
#include "ListOfDoubles.h"
#include <iostream>
using namespace std;

StackOfDoubles::StackOfDoubles(){}

StackOfDoubles::~StackOfDoubles(){}

void StackOfDoubles::push(const double number){ // pushing
    stack.insert(number);
}

void StackOfDoubles::pop(){ // popping
    stack.deleteMostRecent();
}

double StackOfDoubles::top(){ // topping
    return stack.head->theValue;
}

ostream & operator<<(ostream& str, const StackOfDoubles &stackobj){
     stackobj.stack.displayList(str);
     
    return str;
}
