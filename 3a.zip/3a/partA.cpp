//  LabSheet3PartA
//  Dylan Nelson

#include <iostream>
using namespace std;

double inputAndAverage5();
double Average5(double array[], int size);
double AverageN(double array[], int size);


int main (){
    int size = 5;
    double array[size];
    double result = inputAndAverage5();
    
    
    cout << "Your average is: " << result << endl;
    
    cout << "\n";
    
    cout << "Second method:" << endl;
    cout << Average5(array, size) << endl;

    cout << "\n";
    cout << "Third method:" << endl;
    AverageN(array, size) ;cout << endl;
    
}

// PART A
double inputAndAverage5() {
	double totalNumber = 0.0;
	double average;
	double num1, num2, num3, num4, num5;
	double inputArray[5];

	for (int i = 0; i < 5; i++) {
		cout << "Please enter number: " << (i + 1) << endl;
		cin >> inputArray[i];

		totalNumber += inputArray[i];

	}

	average = totalNumber / 5;

	num1 = average - inputArray[0]; // 6 - 5.6
	num2 = average - inputArray[1];
	num3 = average - inputArray[2];
	num4 = average - inputArray[3];
	num5 = average - inputArray[4];


	cout << "The amount which must be added or substracted from each number entered to give the average" << endl;
	cout << "Num1: " << num1 << endl;
	cout << "Num2: " << num2 << endl;
	cout << "Num3: " << num3 << endl;
	cout << "Num4: " << num4 << endl;
	cout << "Num5: " << num5 << endl;

	// Returning the average
	return average;

};




// PART B
double Average5(double array[], int size){
    double totalNumber = 0.0;
    double average;
    
         for (int i = 0; i < size; i++){
             cout << "Please enter number: " << (i+1) << endl;
             cin >> array[i];
             
             totalNumber += array[i];
         }
    average = totalNumber/5;
    
    return average;
}



// PART C
double AverageN(double array[], int size) {

	double totalNumber = 0.0;
	double average;

	for (int i = 0; i < size; i++) {
		cout << "Please enter number: " << (i + 1) << endl;
		cin >> array[i];

		totalNumber += array[i];
	}
	average = totalNumber / 5;

	cout << "The average is: " << average;
	return average;

	return 0;

}


