//  LabSheet2PartA_Part2
//  Dylan Nelson
// https://www.includehelp.com/cpp-programs/airline-seat-reservation-problem.aspx

#include <iostream>
using namespace std;

//Variables
void displaySeats();
string getData();
void check();
void update();
string occupied();


int main() {
	cout << "\tSeats Available" << endl;
	cout << "\t---------------" << endl;
	char array[7][4] = {
		{'A','B','C','D'},
		{'A','B','C','D'},		//displaying seating arrangement
		{'A','B','C','D'},
		{'A','B','C','D'},
		{'A','B','C','D'},
		{'A','B','C','D'},
		{'A','B','C','D'},
	};

	string inputNumber;
	string inputLetter;

	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 4; j++) { 
			cout << array[i][j] << " ";
		}
		cout << endl;
	}


	cout << "\t---------------" << endl; 
	//Enter number of seat row
	cout << "Please enter seat number from above: " << endl;
	cin >> inputNumber;

	//fails if number is greater than 7 or less than 1
	while (inputNumber[0] > '7' || inputNumber[0] < '1') {
		cout << "Number out of bound, please try again: " << endl;
		cin >> inputNumber;

	}
	//Enter seat letter
	cout << "Please enter seat letter (A - D): " << endl;
	cin >> inputLetter;

	//fails if letter is greater than D and less than A
	while (inputLetter[0] > 'D' || inputLetter[0] < 'A') {
		cout << "Letter out of bound, please try again: " << endl;
		cin >> inputLetter;
	}




}


