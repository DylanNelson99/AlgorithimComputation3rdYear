//  Created by Dylan on 21/11/2019.

#ifndef ListOfEmployee_h
#define ListOfEmployee_h
#pragma once

#include<iostream>
using namespace std;
#include"NodeOfEmployee.h"
#include"Employee.h"

class ListOfEmployee {
    friend class NodeOfEmployee;
    friend class Employee;
    friend ostream& operator<<(ostream& outStream, const ListOfEmployee& obj);
public:
    void insertAtFront(string, double);
    void deleteMostRecent();
    double getSalary(string name);
    ListOfEmployee();
    ListOfEmployee(const ListOfEmployee& old);
    ListOfEmployee& operator =(const ListOfEmployee& old);
private:
    NodeOfEmployee* head;
    
};
#endif
