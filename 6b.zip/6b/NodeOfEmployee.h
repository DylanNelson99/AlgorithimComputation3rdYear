//  Created by Dylan on 21/11/2019.


#ifndef NodeOfEmployee_h
#define NodeOfEmployee_h

#pragma once

#include<iostream>
using namespace std;
#include"Employee.h"
class NodeOfEmployee{
    friend class ListOfEmployee;
    friend class Employee;
    
    
public:
    NodeOfEmployee();
    NodeOfEmployee(Employee e);
    friend ostream& operator<<(ostream& outStream, const ListOfEmployee& obj);
    
private:
    NodeOfEmployee* next;
    Employee data;
    
};
#endif
