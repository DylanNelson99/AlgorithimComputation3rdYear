//  Created by Dylan on 21/11/2019.

#include "Employee.h"
#include "ListOfEmployee.h"

Employee::Employee()
{
    name = "";
    salary = 0;
}

Employee::Employee(string n, double s)
{
    name = n;
    salary = s;
}
