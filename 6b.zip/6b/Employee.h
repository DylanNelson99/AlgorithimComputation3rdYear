//  Created by Dylan on 21/11/2019.


#ifndef Employee_h
#define Employee_h
#pragma once


#include<iostream>
using namespace std;


class Employee{
    friend class ListOfEmployee;
    friend class NodeOfEmployee;
    friend ostream& operator<<(ostream& outStream, const ListOfEmployee& obj);
    
public:
    Employee();
    Employee(string n, double s);
    
    
private:
    string name;
    double salary = 0;
};
#endif
