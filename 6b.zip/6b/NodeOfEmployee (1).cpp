//  Created by Dylan on 21/11/2019.


#include "NodeOfEmployee.h"
#include "Employee.h"
#include<iostream>
using namespace std;

NodeOfEmployee::NodeOfEmployee()
:next(NULL), data(Employee())
{
    
}

NodeOfEmployee::NodeOfEmployee(Employee e)
{
    data = e;
}
