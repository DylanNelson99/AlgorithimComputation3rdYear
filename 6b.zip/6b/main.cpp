
//  Created by Dylan on 21/11/2019.

#include<iostream>
using namespace std;

#include "Employee.h"
#include "ListOfEmployee.h"
#include "NodeOfEmployee.h"



int main() {
    
    string name = "Dylan";
    double sal = 100;
    
    
    
    ListOfEmployee test, test2;
    test.insertAtFront(name, sal);
    test.insertAtFront("Leigh", 25);
    test.insertAtFront("Mark", 12);
    
    test.deleteMostRecent();
    
    cout << test.getSalary("Dylan")<<endl;
    
    
    cout << test;
    
    ListOfEmployee test1(test);
    
    cout << test1 << endl;
    
    
    
    test2 = test1;
    cout << test2<<endl;
    
    return 0;
}
