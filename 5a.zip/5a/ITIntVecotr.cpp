
#include "ITIntVector.h"
#include <iostream>
using namespace std;

/*
 public:
     void push_back(int val);
     int size();
     int capacity();
     int resize(int i);
     ITIntVector(int v_size);
     ~ITIntVector();
     // First Version
     const vector <int>& at(int i) const;
     const int& operator[] (int i) const;
     // Second Version
     vector <int>& at(int i);
     int& operator[] (int i);
     
 private:
     int vectorSize;
     int vectorCapacity;
     int* ArrPtr;
    
 */

ITIntVector::ITIntVector(int v_size): vectorSize(v_size),ArrPtr(new int[10]){
    for (int i = 0; i < vectorSize; ++i) {
        ArrPtr[i] = 0;
    }
}

// Returning the current size of the vector
int ITIntVector::size(){
    return vectorSize;
}
// Returns the capacity of the vecotr array
int ITIntVector::capacity(){
    return vectorCapacity;
}
void ITIntVector::resize(int newSize){
    if(newSize > vectorSize){
        ArrPtr[newSize] = 0;
    }
}
ITIntVector::~ITIntVector(){
    cout << "Destructor excecuted" << endl;
    delete[] ArrPtr;
}
void ITIntVector::increase_cap(int cap_size){
    if(cap_size <= vectorCapacity) return;
    
    
    int* new_arrPtr = new int[cap_size];
    for (int i = 0; i < vectorCapacity; ++i) {
        new_arrPtr[i] = ArrPtr[i];
    }
    vectorCapacity = cap_size; // Setting new capacity size
    
    delete[] ArrPtr;
    ArrPtr = new_arrPtr;
}
void ITIntVector::push_back(const int& val){
    if(vectorSize >= vectorCapacity)increase_cap(2 * vectorCapacity);
        ArrPtr[vectorSize] = val;
        ++vectorSize;
    
}


const int& ITIntVector::at(int i) const{
    if(i < 0 || i >= vectorSize) cout << "Range error!" << endl;
    
        return ArrPtr[i];
}

const int& ITIntVector::operator[](int i)const{
   if(i < 0 || i >= vectorSize){
        cout << "Not in range!" << endl;
    }
    return ArrPtr[i];
}
       

int& ITIntVector::operator[](int i){
   if(i < 0 || i >= vectorSize){
        cout << "Not in range!" << endl;
    }
    return ArrPtr[i];
}

