
#ifndef ITIntVector_h
#define ITIntVector_h
#include <vector>
using namespace std;

class ITIntVector{
public:
    void push_back(const int& val);
    int size();
    int capacity();
    void resize(int i);
    void increase_cap(int cap_size);
    
    ITIntVector(int v_size);
    ~ITIntVector();
    // First Version
//    double get(int i) const;
    const int& at(int i) const;
    const int& operator[] (int i) const;
    // Second Version
//    int& at(int i);
    int& operator[] (int i);
    
private:
    int vectorSize;
    int vectorCapacity;
    int* ArrPtr;
    
};



#endif /* ITIntVector_h */
