

#include <iostream>
#include <vector>
#include "ITIntVector.h"
using namespace std;

int main(){
    ITIntVector myVec(5);
    myVec[0] = 5;
    myVec[1] = 6;
    myVec[2] = 7;
    cout << myVec.size() << endl;
    
    cout << myVec.at(0) << endl;
    cout << myVec.at(1) << endl;
    cout << myVec.at(2) << endl;
    
    myVec.push_back(8);
    
    cout << myVec.at(3) << endl; // Not returning 8 ?
    cout << myVec.capacity() << endl;
    
    
}

