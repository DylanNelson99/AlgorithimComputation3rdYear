#include<iostream>;
#include "Percent.h";
using namespace std;


ostream& operator <<(ostream& outputStream, const Percent& aPercent) {
	outputStream << aPercent.value << '%';
	return outputStream;
}

istream& operator >>(istream& inputStream, Percent& aPercent) {

	inputStream >> aPercent.value;

	char percentSign;
	inputStream >> percentSign;

	return inputStream;

}
Percent::Percent() {
	value = 0;
}

Percent::Percent(int v) {
	value = v;
}

const Percent Percent::operator +(const Percent& bPercent) {
	int add = value + bPercent.value;
	return Percent(add);
}
const Percent Percent::operator -(const Percent& bPercent) {
	int sub;
	if (value > bPercent.value) {
		sub = value - bPercent.value;
	}
	else {
		sub = bPercent.value - value;
	}
	return Percent(sub);
}

const Percent Percent::operator *(const Percent& bPercent) {
	double mult1 = value / 100.00;
	double mult2 = bPercent.value / 100.00;
	double mult3;

	mult3 = mult1 * mult2 * 100;
	return Percent(mult3);
}