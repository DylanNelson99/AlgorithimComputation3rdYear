#ifndef MONEY_H
#define MONEY_H

#include <iostream>
using namespace std;
class Money
{
public:
	friend ostream& operator <<(ostream& outStream, const Money& mon);
	Money(int e, int c);
	const Money operator -(const Money& rho) const;
	const Money operator *(const Money& rho) const;
	const Money operator /(const Money& rho) const;
	const bool operator <(const Money& rho) const;
	const bool operator >(const Money& rho) const;
	const bool operator ==(const Money& rho) const;
private:
	int euro, cent;
};

#endif