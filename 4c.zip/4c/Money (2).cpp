#include<iostream>
using namespace std;
#include "Money.h";


ostream& operator <<(ostream& outStream, const Money& mon) {
	if (mon.euro < 0) {
		outStream << "� - ";
	}
	else {
		outStream << "� ";
	}
	outStream << mon.euro << ".";

	if (mon.cent < 10) {
		outStream << "0" << mon.cent << endl;
	}
	else {
		outStream << mon.cent << endl;
	}

	return outStream;
}

Money::Money(int e, int c)
	:euro(e), cent(c)
{};

const Money Money::operator -(const Money& rho) const {
	return Money(euro - rho.euro, cent - rho.cent);
}

const Money Money::operator *(const int& rho) const {
	return Money(euro * rho, cent * rho);
}

const Money Money::operator /(const double& rho) const {
	return Money(trunc(euro / rho), trunc(cent / rho));
}

const bool Money::operator >(const Money& rho) const {
	if (euro > rho.euro) {
		return true;
	}
	else if (euro == rho.euro) {
		if (cent > rho.cent) {
			return true;
		}
	}
	return false;
}
const bool Money::operator <(const Money& rho) const {
	if (euro < rho.euro) {
		return true;
	}
	else if (euro == rho.euro) {
		if (cent < rho.cent) {
			return true;
		}
	}
	return false;
}
const bool Money::operator ==(const Money& rho) const {
	if (euro == rho.euro && cent == rho.cent) {
		return true;
	}
	return false;
}