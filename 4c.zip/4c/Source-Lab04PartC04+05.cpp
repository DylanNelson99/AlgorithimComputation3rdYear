//(Absolute C++, p. 327 & 343)

//2. Is it possible using operator overloading to change the effect of + on integers ?
//Why or why not?
//No, because to overload an operator at least one operand has to be of a class type.

//3. Why can�t we overload << or >> as member operators ?
//Because the left hand side operator of << is ostreamand >> is instram.To
//have them as member operators the first argument would need to be of the class
//type that we're coding in.


#include "Percent.h";
#include<iostream>;
using namespace std;


int main() {
	Percent a, b;
	cout << "Enter the percentage: ";
	cin >> a;

	cout << "Enter the percentage: ";
	cin >> b;

	cout << "a + b = " << a + b << endl;
	cout << "a - b = " << a - b << endl;
	cout << "a * b = " << a * b << endl;

	return 0;
}


// included lab 4 part c task 5 because i cant upload more than 5 files at a time


//#include<iostream>
//using namespace std;
//#include "Money.h"

//int main() {
	//Money a(3, 25), b(10, 50);

	//cout << "b - a = " << b - a; //7.00
	//cout << "a * 2 = " << a * 2; //6.50
	//cout << "b / 2 = " << b / 2; //5.25
	//cout << "b > a = " << (b > a) << endl; // 1
	//cout << "a == b = " << (b == a) << endl; // 0
	//cout << "b < a = " << (b < a) << endl; // 0

	//return 0;
//}