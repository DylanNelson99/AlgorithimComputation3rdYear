#ifndef PERCENT_H
#define PERCENT_H

#include <iostream>
using namespace std;
class Percent
{
public:
	friend bool operator ==(const Percent& first, const Percent& second);
	friend bool operator <(const Percent& first, const Percent& second);
	Percent();
	Percent(int v);
	friend istream& operator >>(istream& inputStream, Percent& aPercent);
	friend ostream& operator <<(ostream& outputStream, const Percent& aPercent);
	const Percent operator +(const Percent& bPercent);
	const Percent operator -(const Percent& bPercent);
	const Percent operator *(const Percent& bPercent);
private:
	int value;
};

#endif