//X00144862 Dylan Nelson

#include <iostream>
#include "NodeOfInts.h"
#include "ListOfInts.h"
using namespace std;
int main(){
    ListOfInts ob;
    ob.insert(5);
    ob.insert(6);
    ob.insert(7);
    ob.displayList();
    ob.deleteMostRecent();
//    ob.deleteInt(2);
    cout << "New List!"<< endl;
    
    ob.displayList();
}




    
