//X00144862 Dylan Nelson

#ifndef NodeOfInts_h
#define NodeOfInts_h
class NodeOfInt{
    friend class ListOfInts;
public:
    NodeOfInt(int);
private:
    int data;
    NodeOfInt* next;
};

typedef NodeOfInt* ListNodePtr; 

#endif /* NodeOfInts_h */
