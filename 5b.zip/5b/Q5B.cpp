// Dylan Nelson X00144862

#include <iostream>
using namespace std;
int main() {
 /*   ....this program is buggy

    double *d = new double;
     unsigned here just tells us that, we ensure that it is only positive numbers.
     Without the unsigned the int will range from -32000 to 32000. But with the
     unsigned int it will range from 0 - 65000.
    
   for(unsigned int i = 0; i < 3; i++) {
        d[i] =  1.5 + i;
     }

   for(unsigned int i = 2; i >= 0; i--) {
        cout << d[i] << endl;
     }
   
     It prints "chr is y" because || is expecting two conditions, and here
     we only have one. So at this point it's not going to reach the else if and else
     statement because it breaks at the if statement
    
    char chr = 'N';

    if (chr == 'Y' || 'y')
     cout << "chr is y" << endl;

    else if (chr == 'N' || 'n')
     cout << "chr is n" << endl;
    else
     cout << "chr is something else" << endl;
    

    int t1[] = {0,0,1,1,1}; // declaring an array called t1
    int t2[] = {0,0,1,1,1}; // declaring an arrat called t2
 
    int *p1 = t1; // allocating the
    int *p2 = t2;

    while (!*p1++ || !*p2++);

    cout << (p1-t1) << endl;

    cout << (p2-t2) << endl;
    
    

    
     Both programs are not equivalent.
     Here count2 is being incremented normally, but everytime
     it gets printed out, it is set to one first.
    int count2 = 1;
    for (; count2 <= 5 ; count2++)
    {
    int count2 = 1;
    cout << count2 << "\n";
    }
    
    cout << "----------" << endl;
     this program is an infinite loop
     while loop does not meet its end
     the count++ refers to a different variable
    int count = 1;
    while (count <= 5)
    {
    int count = 1;
    cout << count << "\n";
    count++;

    }
        return 0;  */
}
