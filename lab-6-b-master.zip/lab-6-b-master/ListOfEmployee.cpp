#include "ListOfEmployee.h"
#include "Employee.h"
#include "NodeOfEmployee.h"
#include<iostream>
using namespace std;
void ListOfEmployee::insertAtFront(string nameIn, double salIn)
{
	Employee emp = Employee(nameIn, salIn);
	NodeOfEmployee* temp_node = new NodeOfEmployee(emp);
	temp_node->next = head;
	head = temp_node;

}

void ListOfEmployee::deleteMostRecent()
{
	if (head) {
		NodeOfEmployee* temp_node = head;
		head = head->next;
		delete temp_node;
		temp_node = NULL;
	}
}

double ListOfEmployee::getSalary(string name)
{
	NodeOfEmployee* temp_node = head;
	double sal = 0;
	while (temp_node) {
		if (temp_node->data.name == name) {
			sal = temp_node->data.salary;
		}
		temp_node = temp_node->next;
	}

	return sal;
}

ListOfEmployee::ListOfEmployee()
	:head(NULL)
{
}

ListOfEmployee::ListOfEmployee(const ListOfEmployee& old)
{
	*this = old;
}

ListOfEmployee& ListOfEmployee::operator=(const ListOfEmployee& rhs)
{
	if (this != &rhs) {
		if (rhs.head != NULL) {
			while (head) {
				NodeOfEmployee* iterator = head;
				head = head->next;
				delete iterator;
				cout << "Node deleted " << endl;
			}

			head = new NodeOfEmployee(rhs.head->data);
			cout << " Copying the first node"<<endl;
			NodeOfEmployee* newptr = head;
			NodeOfEmployee* iterator = rhs.head->next;

			while (iterator) {
				newptr->next = new NodeOfEmployee(iterator->data);
				iterator = iterator->next;
				newptr = newptr->next;
			}


		}
		
	}
	return *this;
}

ostream& operator<<(ostream& outputStream,const ListOfEmployee& obj)
{
	 NodeOfEmployee* temp_node = obj.head;

	while (temp_node) {
		outputStream << "Name: " << temp_node->data.name << " , " << "Salary: " << temp_node->data.salary << endl;

		temp_node = temp_node->next;
	}
	return outputStream;

	
}
