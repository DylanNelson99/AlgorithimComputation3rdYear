#pragma once
#ifndef NODEOFEMPLOYEE_H
#define NODEOFEMPLOYEE_H
#include<iostream>
using namespace std;
#include"Employee.h"
class NodeOfEmployee{
	friend class ListOfEmployee;
	friend class Employee;

	
public:
	NodeOfEmployee();
	NodeOfEmployee(Employee e);
	friend ostream& operator<<(ostream& outStream, const ListOfEmployee& obj);

private:
	NodeOfEmployee* next;
	Employee data;

};
#endif