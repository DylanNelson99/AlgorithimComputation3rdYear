#pragma once
#ifndef LISTOFEMPLOYEE_H
#define LISTOFEMPLOYEE_H
#include<iostream>
using namespace std;
#include"NodeOfEmployee.h"
#include"Employee.h"
class ListOfEmployee {
	friend class NodeOfEmployee;
	friend class Employee;
	friend ostream& operator<<(ostream& outStream, const ListOfEmployee& obj);
public:
	void insertAtFront(string, double);
	void deleteMostRecent();
	double getSalary(string name);
	ListOfEmployee();
	ListOfEmployee(const ListOfEmployee& old);
	ListOfEmployee& operator =(const ListOfEmployee& old);
private:
	NodeOfEmployee* head;

};
#endif 