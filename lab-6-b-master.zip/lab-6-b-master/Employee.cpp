#include "Employee.h"
#include "ListOfEmployee.h"

Employee::Employee()
{
	name = "";
	salary = 0;
}

Employee::Employee(string n, double s)
{
	name = n;
	salary = s;
}





