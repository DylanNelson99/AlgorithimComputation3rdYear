#include <iostream>
#include <fstream>
using namespace std;

int main(){
	int currentSalary;
	int newSalary;
	int retroPay;
	int monthlySalary;

	ofstream myfile;
	myfile.open("Text.txt");


	// Here I will gather the information from the user
	cout << "\n";
	cout << "What is your current Salary?: ";
	cin >> currentSalary;

	//Here I will create my formuals

	newSalary = currentSalary * 1.076;

	monthlySalary = newSalary / 12;

	retroPay = (newSalary - currentSalary) / 2;

	//Now I will display the output to the user

	cout << "\n";
	cout << "Your new yearly salary is: ";
	cout << newSalary;
	cout << "\n";

	cout << "Your new monthly salary is: ";
	cout << monthlySalary;
	cout << "\n";

	cout << "And the company owes you: ";
	cout << retroPay;
	cout << "\n";

	myfile.close();
	return 0;
}