#include<iostream>
using namespace std;
int main() { //variables
	double normaltime;
	double ottime;
	double hours;
	double rate;
	double salary;
	bool again = true;
	char answer;

	while (again == true) {//begining while loop for calculating salaries



		cout << "Please enter in the number of hours worked: ";
		cin >> hours;//adding the number to hours
		cout << "Please enter your rate: ";
		cin >> rate;//adding the number to rate


		if (hours > 40) { //calculating overtime
			normaltime = 40 * rate;
			ottime = (hours - 40) * (rate * 1.5);

			salary = normaltime + ottime;

			cout << "Gross pay: " << salary;
		}
		else if (hours < 40) {//calculating if no overtime
			salary = hours * rate;

			cout << "Gross pay: " << salary;
		}

		cout << " Would you like to enter in details for another employee?: (Y/N) (y/n) "; // asking to restart for a new employee
		cin >> answer;

		if (answer == 'Y'||answer == 'y') {// (Y/y) to continue 
			again = true;

		}
		else if(answer == 'N' || answer == 'n') {// (N/n) to exit
			again = false;

		}


	}
}