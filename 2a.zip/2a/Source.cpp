#include <iostream>
using namespace std;

int main()
{
	//Initialising Variables
	int bars=0;
	int coupons=0;
	double userMoney=0;

	cout << "Enter the amount of money you have to spend" << endl; // Entering your money
	cin >> userMoney;

	bars = userMoney / 1.50; // getting amout of bars for your money
	coupons = bars; // amount of bars gives you the amount of coupons

	while (coupons >= 9) {           // calculates the extra bars you get if you have enough coupons
		coupons = (coupons - 9);
		bars++;
		coupons++;
	}

	//outputs results
	cout << "You can buy " << bars << " bars ";
	cout << " and will have " << coupons << " unused coupon(s) " << endl;

	return 0;

}